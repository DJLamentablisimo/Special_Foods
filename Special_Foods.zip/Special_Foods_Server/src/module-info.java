module Special_Foods_Server {
	requires java.rmi;
}