For MAC users, copy this command on a terminal.

rmiregistry -J-Djava.rmi.server.useCodebaseOnly=false